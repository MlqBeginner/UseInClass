package game;

import java.util.Random;

public class Text {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Player player=new Player();
		player.play();
	}

}
